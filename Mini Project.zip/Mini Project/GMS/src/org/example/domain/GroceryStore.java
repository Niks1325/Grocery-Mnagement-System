package org.example.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.example.utils.Customer;
import org.example.utils.Order;
import org.example.utils.Product;

public class GroceryStore {
	private String name;
    private String address;
    private String phone;
    private String email;
    private Map<String, Product> products;
    private Set<Customer> customers;
    private List<Order> orders;
  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public GroceryStore(String name, String address, String phone, String email) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.products = new HashMap<>();
        this.customers = new HashSet<>();
        this.orders = new ArrayList<>();
    }
	
	public void addProduct(Product product) {
		  products.put(product.getName(), product);
	}
	public void removeProduct(String name2) {
		 products.remove(name);
		
	}
    
	
   }