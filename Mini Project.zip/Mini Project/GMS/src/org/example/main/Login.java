package org.example.main;

import java.util.Scanner;

public class Login {

	String username;
    String password;
    boolean loggedIn = false;
	
private static Scanner sc = new Scanner(System.in);
       

public void loginconsole(){
	System.out.println("Login");
	System.out.print("1.Name - ");
	String uname = sc.nextLine();
	System.out.print("1.Employee ID - ");
	String uid = sc.nextLine();
	System.out.print("2.Password -  ");
	String upss = sc.nextLine();
	System.out.println();

	
		if ("admin".equals(uname) && "123".equals(uid) && "admin".equals(upss)) 
	        System.out.println(" User successfully logged-in");
	     else 
	        System.out.println(" In valid userName of password ");
        
    }
	
	
}


