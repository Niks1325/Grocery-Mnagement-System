package org.example.main;

import java.util.Scanner;

import org.example.domain.GroceryStore;
import org.example.utils.Product;

public class Program {
	
	 private static GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
	
	private static void addProduct() {
		  System.out.print("Enter product name: ");
          String name = sc.nextLine();
          System.out.print("Enter product description: ");
          String description = sc.nextLine();
          System.out.print("Enter product price: ");
          double price = sc.nextDouble();
          System.out.print("Enter product quantity: ");
          int quantity = sc.nextInt();
          sc.nextLine();
          Product product = new Product(name, description, price, quantity);
          store.addProduct(product);
		
	}
	
	private static void removeProduct() {
		System.out.print("Enter product name: ");
        String name = sc.nextLine();
        store.removeProduct(name);
		
	}
	
	private static void updateProduct() {
		String name;
		System.out.print("Enter product name: ");
        name = sc.nextLine();
        System.out.print("Enter new product name: ");
        String newName = sc.nextLine();
        sc.nextLine();
        System.out.print("Enter new product description: ");
        String newDescription = sc.nextLine();
        System.out.print("Enter new product price: ");
        double newPrice = sc.nextDouble();
        System.out.print("Enter new product quantity: ");
        int newQuantity = sc.nextInt();
        sc.nextLine();
        
        Product product = new Product(newName, newDescription, newPrice, newQuantity);
        //store.updateProduct(name, product);
		
	}
	
	private static void viewProducts() {
		// TODO Auto-generated method stub
		
	}
	
	private static void searchProducts() {
		// TODO Auto-generated method stub
		
	}
	
	private static Scanner sc = new Scanner(System.in);
	
	public static int mainMenu(){
		
		 System.out.println("1. Add product");
         System.out.println("2. Remove product");
         System.out.println("3. Update product");
         System.out.println("4. View products");
         System.out.println("5. Search products");
         System.out.println("6. Add customer");
         System.out.println("7. Remove customer");
         System.out.println("8. View customers");
         System.out.println("9. Create order");
         System.out.println("10. View orders");
         System.out.println("0. Exit");
         System.out.print("Enter choice: ");
         return sc.nextInt();
	}

	public static void main(String[] args) {
		System.out.println("------------------------------------------------------------------------------------------  ");
		System.out.println("---------------------------------Welcome to P-Mart Admin Panel------------------------------");
		System.out.println("------------------------------------------------------------------------------------------  ");
		
		/*
		Login lg = new Login();
		lg.loginconsole();
		
		if(true) Program. addProduct();
			Program.mainMenu();
		else(false)
		*/
		
		int choice;
		
		while((choice = Program.mainMenu()) != 0)
		{
			switch(choice)
		    {
			case 1 :
				Program.addProduct();
				break;
			case 2 :
				Program.removeProduct();
				break;
			case 3 :
				Program.updateProduct();
				break;
			case 4 :
				Program.viewProducts();
				break;
			case 5 :
				Program.searchProducts();
				break;
			case 6 :
				break;
			case 7 :
				break;
				
			
		
		
	}
}
	}


	
}
