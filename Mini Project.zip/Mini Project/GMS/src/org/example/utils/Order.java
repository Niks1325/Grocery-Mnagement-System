package org.example.utils;

import java.util.Map;

public class Order {

	 private Customer customer;
	    private Map<Product, Integer> items;
	    private double total;

	    public Order(Customer customer, Map<Product, Integer> items, double total) {
	        this.customer = customer;
	        this.items = items;
	        this.total = total;
	    }

	    @Override
	    public String toString() {
	        StringBuilder sb = new StringBuilder();
	        sb.append("Customer: ").append(customer.getName()).append("\n");
	        sb.append("Items:\n");
	        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
	            Product product = entry.getKey();
	            int quantity = entry.getValue();
	            sb.append(product.getName()).append(" - ").append(quantity).append("\n");
	        }
	        sb.append("Total: $").append(total);
	        return sb.toString();
	    }
	}

