import java.util.*;

public class GroceryStore {
    private String name;
    private String address;
    private String phone;
    private String email;
    private Map<String, Product> products;
    private Set<Customer> customers;
    private List<Order> orders;

    public GroceryStore(String name, String address, String phone, String email) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.products = new HashMap<>();
        this.customers = new HashSet<>();
        this.orders = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.put(product.getName(), product);
    }

    public void removeProduct(String name) {
        products.remove(name);
    }

    public void updateProduct(String name, Product product) {
        products.put(name, product);
    }

    public void viewProducts() {
        for (Product product : products.values()) {
            System.out.println(product);
        }
    }

    public void searchProducts(String name) {
        for (Product product : products.values()) {
            if (product.getName().equalsIgnoreCase(name)) {
                System.out.println(product);
            }
        }
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void removeCustomer(Customer customer) {
        customers.remove(customer);
    }

    public void viewCustomers() {
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }

    public void createOrder(Customer customer, Map<Product, Integer> items) {
        double total = 0;
        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            if (product.getQuantity() < quantity) {
                System.out.println("Insufficient stock for " + product.getName());
                return;
            }
            total += product.getPrice() * quantity;
            product.setQuantity(product.getQuantity() - quantity);
        }
        Order order = new Order(customer, items, total);
        orders.add(order);
    }

    public void viewOrders() {
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
        while (true) {
            System.out.println("1. Add product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product");
            System.out.println("4. View products");
            System.out.println("5. Search products");
            System.out.println("6. Add customer");
            System.out.println("7. Remove customer");
            System.out.println("8. View customers");
            System.out.println("9. Create order");
            System.out.println("10. View orders");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter product description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter product price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter product quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();
                    Product product = new Product(name, description, price, quantity);
                    store.addProduct(product);
                    break;
                case 2:
                    System.out.print("Enter product name: ");
                    name = scanner.nextLine();
                    store.removeProduct(name);
                    break;
                case 3:
                    System.out.print("Enter product name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new product name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new product description: ");
                    String newDescription = scanner.nextLine();
                    System.out.print("Enter new product price: ");
                    double newPrice = scanner.nextDouble();
                    System.out.print("Enter new product quantity: ");
                    int newQuantity = scanner.nextInt();
                    scanner.nextLine();
                    product = new Product(newName, newDescription, newPrice, newQuantity);
                    store.updateProduct(name, product);
                    break;
                case 4:
                    store.viewProducts();
                    break;
                case 5:
                    System.out.print("Enter product name: ");
                    name = scanner.nextLine();
                    store.searchProducts(name);
                    break;
                case 6:
                    System.out.print("Enter  customer name: ");
                    String customerName = scanner.nextLine();
                    System.out.print("Enter customer address: ");
                    String customerAddress = scanner.nextLine();
                    System.out.print("Enter customer phone: ");
                    String customerPhone = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String customerEmail = scanner.nextLine();
                    Customer customer = new Customer(customerName, customerAddress, customerPhone, customerEmail);
                    store.addCustomer(customer);
                    break;
                case 7:
                    System.out.print("Enter customer name: ");
                    customerName = scanner.nextLine();
                    customer = new Customer(customerName, "", "", "");
                    store.removeCustomer(customer);
                    break;
                case 8:
                    store.viewCustomers();
                    break;
                case 9:
                    System.out.print("Enter customer name: ");
                    customerName = scanner.nextLine();
                    customer = new Customer(customerName, "", "", "");
                    if (!store.customers.contains(customer)) {
                        System.out.println("Customer not found");
                        break;
                    }
                    Map<Product, Integer> items = new HashMap<>();
                    while (true) {
                        System.out.print("Enter product name (or 0 to finish): ");
                        name = scanner.nextLine();
                        if (name.equals("0")) {
                            break;
                        }
                        if (!store.products.containsKey(name)) {
                            System.out.println("Product not found");
                            continue;
                        }
                        System.out.print("Enter quantity: ");
                        quantity = scanner.nextInt();
                        scanner.nextLine();
                        items.put(store.products.get(name), quantity);
                    }
                    store.createOrder(customer, items);
                    break;
                case 10:
                    store.viewOrders();
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}

class Product {
    private String name;
    private String description;
    private double price;
    private int quantity;

    public Product(String name, String description, double price, int quantity) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return name + " - " + description + " - $" + price + " - " + quantity + " in stock";
    }
}

class Customer {
    private String name;
    private String address;
    private String phone;
    private String email;

    public Customer(String name, String address, String phone, String email) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name + " - " + address + " - " + phone + " - " + email;
    }
}

class Order {
    private Customer customer;
    private Map<Product, Integer> items;
    private double total;

    public Order(Customer customer, Map<Product, Integer> items, double total) {
        this.customer = customer;
        this.items = items;
        this.total = total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(customer.getName()).append("\n");
        sb.append("Items:\n");
        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            sb.append(product.getName()).append(" - ").append(quantity).append("\n");
        }
        sb.append("Total: $").append(total);
        return sb.toString();
    }
}