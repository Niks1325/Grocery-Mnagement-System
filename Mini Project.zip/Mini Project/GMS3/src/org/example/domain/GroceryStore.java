package org.example.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



import org.example.utils.Customer;
import org.example.utils.Employee;
import org.example.utils.Order;
import org.example.utils.Product;

public class GroceryStore {
	    private String name;
	    private String address;
	    private String phone;
	    private String email;
	    private Map<String, Product> products;
	    private List<Order> orders;
        
	    static HashSet<Employee> employees = new HashSet<>();
	    static ArrayList<Customer> customers = new ArrayList<>();
	    //static ArrayList<Order> orders = new ArrayList<>();

	    
	    public GroceryStore() {
		}

		public GroceryStore(String name, String address, String phone, String email) {
	        this.name = name;
	        this.address = address;
	        this.phone = phone;
	        this.email = email;
	        this.products = new HashMap<>();
	        this.orders = new ArrayList<>();
	       
	    }
		
		
        //--------------------------------------- Scanner--------------------------------------------------------------
	     static Scanner scanner = new Scanner(System.in);
	    
	    //--------------------------------------- Product--------------------------------------------------------------
	    public void addProduct(Product product) {
	        products.put(product.getName(), product);
	    }

	    public void removeProduct(String name) {
	        products.remove(name);
	    }

	    public void updateProduct(String name, Product product) {
	        products.put(name, product);
	    }

	    public void viewProducts() {
	        for (Product product : products.values()) {
	            System.out.println(product);
	        }
	    }

	    public void searchProducts(String name) {
	        for (Product product : products.values()) {
	            if (product.getName().equals(name)) {
	                System.out.println(product);
	            }
	            else {
	            	System.out.println("Not Found");
	            }
	        }
	    }

	    //--------------------------------------- Customer-------------------------------------------------------------
	    
	    private void addCustomer() {
			  System.out.print("Enter Customer Name: ");
		        String name = scanner.next();

		        // Check if Customer with same ID already exists
		        for (Customer c : customers) {
		            if (c.getName() == name) {
		                System.out.println("Employee with ID " + name + " already exists.");
		                return;
		            }
		        }

		        System.out.print("Enter Customer address: ");
		        String address = scanner.next();

		        System.out.print("Enter Customer Phone: ");
		        String phone = scanner.next();
		        
		        System.out.print("Enter Customer email: ");
		        String email = scanner.next();
		        
		        Customer newCustomer = new Customer(name, address, phone, email);
		       
		        customers.add(newCustomer);

		        System.out.println("Customer added successfully.");
		}

	    private Customer findPerson(String name) {
			   for (Customer newcustomer : customers) {
	                if (newcustomer.getName().equals(name)) {
	                	System.out.println("Customer Found");
	                	System.out.println(newcustomer);
		              }
	                else {
	                	System.out.println("Customer Not Found");
	                     }
			   }
	              return null;
		        }
 

	    private void removeCustomer(String name2) {
	    	for (Customer newcustomer : customers) {
                if (newcustomer.getName().equals(name2)) {
                	 customers.remove(newcustomer);
                	 System.out.println("Customer Removed");
                	 break;
                }
                else {
                	System.out.println("Customer Not Found");
                     }
	    	}
	    }
			
		
	    public void viewCustomers() {
	        for (Customer customer : customers) {
	            System.out.println(customer);
	        }
	        
	    }
	   
	   //--------------------------------------- Employee-------------------------------------------------------------
	    
	    private void removeEmployee() {
			 System.out.print("Enter employee ID: ");
		        int id = scanner.nextInt();

		        for (Employee e : employees) {
		            if (e.getId() == id) {
		                employees.remove(e);
		                System.out.println("Employee removed successfully.");
		                return;
		            }
		        }

		        System.out.println("Employee with ID " + id + " not found.");
		    }
			


		private void addEmployee() {
			System.out.print("Enter employee ID: ");
	        int id = scanner.nextInt();

	        // Check if employee with same ID already exists
	        for (Employee e : employees) {
	            if (e.getId() == id) {
	                System.out.println("Employee with ID " + id + " already exists.");
	                return;
	            }
	        }

	        System.out.print("Enter employee name: ");
	        String name = scanner.next();

	        System.out.print("Enter employee salary: ");
	        double salary = scanner.nextDouble();

	        Employee newEmployee = new Employee(id, name, salary);
	        employees.add(newEmployee);

	        System.out.println("Employee added successfully.");
			
		}

		 private void findEmployee() {
			System.out.print("Enter employee ID: ");
	        int id = scanner.nextInt();

	        for (Employee e : employees) {
	            if (e.getId() == id) {
	                System.out.println("Employee found:");
	                System.out.println(e);
	                return;
	            }
	        }

	        System.out.println("Employee with ID " + id + " not found.");
			
		}
		 private void viewEmployee() {
		        Iterator<Employee> it = employees.iterator();
		        while(it.hasNext()) {
		            System.out.println(it.next());
		        }
		    }
			
	 //--------------------------------------- Order--------------------------------------------------------------
	    public void createOrder(Customer customer, Map<Product, Integer> items) {
	        double total = 0;
	        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
	            Product product = entry.getKey();
	            int quantity = entry.getValue();
	            if (product.getQuantity() < quantity) {
	                System.out.println("Insufficient stock for " + product.getName());
	                return;
	            }
	            total += product.getPrice() * quantity;
	            product.setQuantity(product.getQuantity() - quantity);
	        }
	        Order order = new Order(customer, items, total);
	        orders.add(order);
	    }

	    public void viewOrders() {
	        for (Order order : orders) {
	            System.out.println(order);
	        }
	    }
	    
	    
	    //-------------------------------------------MENU-----------------------------------------------
	    public static int productMenu(){
	    	 System.out.println("1. Add product");
	            System.out.println("2. Remove product");
	            System.out.println("3. Update product");
	            System.out.println("4. View products");
	            System.out.println("5. Search products");
	            System.out.println("0. Exit");
	            
	            System.out.print("Enter choice: ");
	            return scanner.nextInt();
		}
	    
	    private static int customerMenu() {
    	    System.out.println("1. Add customer");
    	    System.out.println("2. Find customers");
            System.out.println("3. View customers");
            System.out.println("4. Remove customer");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            return scanner.nextInt();
		
	}
	    private static int employeeMenu() {
	    	System.out.println("1. Add Employee");
	    	System.out.println("2. Find Employee");
            System.out.println("3. Remove Employee");
            System.out.println("4. View Employee");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            return scanner.nextInt();
		}
	    
	    private static int orderMenu() {
			System.out.println("1. Create order");
            System.out.println("2. View orders");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            return scanner.nextInt();
		}
	

	    
        //--------------------------------------- CALLING METHODS--------------------------------------------------------------
	    //-------------------------------------------PRODUCT-----------------------------------------------
	    public void productcontent () {
	    	GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
	    	int choice;
	    	while((choice = GroceryStore.productMenu()) != 0) {
	            switch (choice) {
	                case 1:
	                    System.out.print("Enter product name: ");
	                    scanner.nextLine();
	                    String name = scanner.nextLine();
	                    System.out.print("Enter product description: ");
	                    String description = scanner.nextLine();
	                    System.out.print("Enter product price: ");
	                    double price = scanner.nextDouble();
	                    System.out.print("Enter product quantity: ");
	                    int quantity = scanner.nextInt();
	                    scanner.nextLine();
	                    Product product = new Product(name, description, price, quantity);
	                    store.addProduct(product);
	                    break;
	                case 2:
	                    System.out.print("Enter product name: ");
	                    scanner.nextLine();
	                    name = scanner.nextLine();
	                    store.removeProduct(name);
	                    break;
	                case 3:
	                    System.out.print("Enter product name: ");
	                    scanner.nextLine();
	                    name = scanner.nextLine();
	                    System.out.print("Enter new product name: ");
	                    String newName = scanner.nextLine();
	                    System.out.print("Enter new product description: ");
	                    String newDescription = scanner.nextLine();
	                    System.out.print("Enter new product price: ");
	                    double newPrice = scanner.nextDouble();
	                    System.out.print("Enter new product quantity: ");
	                    int newQuantity = scanner.nextInt();
	                    scanner.nextLine();
	                    product = new Product(newName, newDescription, newPrice, newQuantity);
	                    store.updateProduct(name, product);
	                    break;
	                case 4:
	                    store.viewProducts();
	                    break;
	                case 5:
	                    System.out.print("Enter product name: ");
	                    scanner.nextLine();
	                    name = scanner.nextLine();
	                    store.searchProducts(name);
	                    break;
	                case 0:
	                    break;
	                default:
	                    System.out.println("Invalid choice");
	            } 
	        }
	    }
	    
	  //-------------------------------------------CUSTOMER-----------------------------------------------
	    public void customercontent () {
	    	GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
			           int choice;
			    	   while((choice = GroceryStore.customerMenu()) != 0) {
			            switch (choice) {
			            case 1: 
			            	store.addCustomer();
		                    break;
		                case 2:
		                	 System.out.print("Enter a name to find ");
		                     String name = scanner.next();
		                     store.findPerson(name);
		                    break;
		                case 3:
		                    store.viewCustomers();
		                    break;
		                case 4:
		                	System.out.print("Enter a name to remove ");
		                    String name2 = scanner.next(); 
		                	store.removeCustomer(name2);
		                    break;
		                case 0:
		                    System.exit(0);
		                default:
		                    System.out.println("Invalid choice");
		            }
	           }
		   }


	//-------------------------------------------EMPLOYEE-----------------------------------------------
	    public void employeeContent () {
	    	GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
			           int choice;
			    	   while((choice = GroceryStore.employeeMenu()) != 0) {
			            switch (choice) {
			            
			            case 1: 
			            	store.addEmployee();
		                    break;
		                  
		                case 2: 
		                	store.findEmployee();
		                    break;
		                    
		                case 3:
		                	store.removeEmployee();
		                    break;
		                
		                case 4:
		                	store.viewEmployee();
		                	
		                case 0:
		                    System.exit(0);
		                default:
		                    System.out.println("Invalid choice");
		            }
	           }
		   }
	

	//-------------------------------------------ORDER-----------------------------------------------
		public void orderBilling () {
	    	GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
	    	Customer customer = new Customer(name, address,  phone,  email);
	    	//Product product = new Product();
	    	int choice;
	    	while((choice = GroceryStore.orderMenu()) != 0) {
           
		            switch (choice) {
		                case 1:
		                	 System.out.print("Enter customer name: ");
		                	 scanner.nextLine();
			                 String customerName = scanner.nextLine();
			                 
	
			                 customer = new Customer(customerName, "", "", "");
			                 for (Customer newcustomer : customers) {
			                     if (newcustomer.getName().equals(customerName)) {
			                    	 Map<Product, Integer> items = new HashMap<>();
					                 while (true) {
					                        System.out.print("Enter product name (or 0 to finish): ");
					                        //scanner.nextLine();
					                        int productName = scanner.nextInt();
					                        if (productName == 0) {
					                            break;
					                        }
					                        if (store.products.containsKey(productName)) {
					                        	System.out.print("Enter quantity: ");
						                        int quantity = scanner.nextInt();
						                        scanner.nextLine();
						                        items.put(store.products.get(name), quantity); 
					                        }
					                        else {
					                        	System.out.println("Product not found");
					                            continue;
					                        }
					                    }
					                    store.createOrder(customer, items);
			                    break;
			                     }
			                     else {
			                     	System.out.println("Customer Not Found");
			                          }
			               
			                 /*
			                 if (!store.customers.equals(customerName)) 
			                 {
			                    System.out.println("Customer not found");
			                    break;
			                 }
			                 
			                 Map<Product, Integer> items = new HashMap<>();
			                 while (true) {
			                        System.out.print("Enter product name (or 0 to finish): ");
			                        scanner.nextLine();
			                        name = scanner.nextLine();
			                        if (name.equals("0")) {
			                            break;
			                        }
			                        if (!store.products.containsKey(name)) {
			                            System.out.println("Product not found");
			                            continue;
			                        }
			                        System.out.print("Enter quantity: ");
			                        int quantity = scanner.nextInt();
			                        scanner.nextLine();
			                        items.put(store.products.get(name), quantity);
			                    }
			                    store.createOrder(customer, items);
			                    */
			                 }
		                	break;
		                case 10:
		                    store.viewOrders();
		                    break;
		                case 0:
		                    System.exit(0);
		                default:
		                    System.out.println("Invalid choice");
		            }
	          }
        }
	    }

