package org.example.main;

import java.util.Scanner;

import org.example.domain.GroceryStore;


public class Program {
	
	private static Scanner sc = new Scanner(System.in);
	
	public static int mainMenu(){
		
		 System.out.println("\t1. Product Management");
         System.out.println("\t2. Customer Record");
         System.out.println("\t3. Order");
         System.out.println("\t4. Manage Employee");
         System.out.println("\t0. Exit");
         System.out.print("Enter choice: ");
         return sc.nextInt();
	}

	public static void main(String[] args) {
		System.out.println("------------------------------------------------------------------------------------------  ");
		System.out.println("---------------------------------Welcome to NP-Mart Admin Panel------------------------------");
		System.out.println("------------------------------------------------------------------------------------------  ");
		
		Scanner scanner = new Scanner(System.in);
		final String USERNAME = "admin";
		final String PASSWORD = "password";

		   
		       

		        // Prompt user for login
		        boolean loggedIn = false;
		        
		        while (!loggedIn) {
		            System.out.print("Enter username: ");
		            String username = scanner.nextLine();

		            System.out.print("Enter password: ");
		            String password = scanner.nextLine();

		            if (username.equals(USERNAME) && password.equals(PASSWORD)) {
		                System.out.println("Login successful!");
		                loggedIn = true;
		            } else {
		                System.out.println("Invalid username or password. Please try again.");
		            }
		        }

	while (loggedIn) {
		GroceryStore store = new GroceryStore("My Store", "123 Main St", "555-1234", "info@mystore.com");
		int choice;
		while((choice = Program.mainMenu()) != 0)
		{
			switch(choice)
		    {
			case 1 :
				store.productcontent();
				break;
			case 2 :
				store.customercontent();
				break;
			case 3 :
				store.orderBilling();
				break;
			case 4 :
				store.employeeContent();
				break;
		
 
	          }
          }
		scanner.close();
	  }
   }
}
