package org.example.utils;

public class Employee {
	

	private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

  

    // Override hashCode() and equals() to ensure proper functioning of HashSet
    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Employee)) {
            return false;
        }
        Employee e = (Employee) obj;
        return e.getId() == this.id;
    }
    
	 
	 @Override
	    public String toString() {
	        return "ID: " + id + ", Name: " + name + ", Salary: " + salary;
	    }
}
