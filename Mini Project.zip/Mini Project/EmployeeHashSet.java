import java.util.HashSet;
import java.util.Scanner;

public class EmployeeHashSet {

    static HashSet<Employee> employees = new HashSet<>();

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter your choice:");
            System.out.println("1. Add employee");
            System.out.println("2. Find employee");
            System.out.println("3. Remove employee");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addEmployee(scanner);
                    break;
                case 2:
                    findEmployee(scanner);
                    break;
                case 3:
                    removeEmployee(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    static void addEmployee(Scanner scanner) {
        System.out.print("Enter employee ID: ");
        int id = scanner.nextInt();

        // Check if employee with same ID already exists
        for (Employee e : employees) {
            if (e.getId() == id) {
                System.out.println("Employee with ID " + id + " already exists.");
                return;
            }
        }

        System.out.print("Enter employee name: ");
        String name = scanner.next();

        System.out.print("Enter employee salary: ");
        double salary = scanner.nextDouble();

        Employee newEmployee = new Employee(id, name, salary);
        employees.add(newEmployee);

        System.out.println("Employee added successfully.");
    }

    static void findEmployee(Scanner scanner) {
        System.out.print("Enter employee ID: ");
        int id = scanner.nextInt();

        for (Employee e : employees) {
            if (e.getId() == id) {
                System.out.println("Employee found:");
                System.out.println(e);
                return;
            }
        }

        System.out.println("Employee with ID " + id + " not found.");
    }

    static void removeEmployee(Scanner scanner) {
        System.out.print("Enter employee ID: ");
        int id = scanner.nextInt();

        for (Employee e : employees) {
            if (e.getId() == id) {
                employees.remove(e);
                System.out.println("Employee removed successfully.");
                return;
            }
        }

        System.out.println("Employee with ID " + id + " not found.");
    }
}

class Employee {
    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Salary: " + salary;
    }

    // Override hashCode() and equals() to ensure proper functioning of HashSet
    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Employee)) {
            return false;
        }
        Employee e = (Employee) obj;
        return e.getId() == this.id;
    }
}